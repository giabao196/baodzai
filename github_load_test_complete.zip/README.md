# GitHub Load Test Web

## 1. Tạo repository

Tạo một repository GitHub mới, ví dụ `load-test-web`.

## 2. Upload file

Upload toàn bộ cấu trúc này:

```text
index.html
README.md
.github/
└── workflows/
    └── pages.yml
```

Commit vào `main`.

## 3. Bật GitHub Pages

Vào:

`Settings -> Pages -> Build and deployment -> Source: GitHub Actions`

Sau khi workflow chạy xong, GitHub sẽ cung cấp URL Pages.

## 4. Giao diện

- Domain
- 1–10.000 requests
- 1–500 RPS
- START / STOP
- Progress
- Requests / Success / Error / RPS

GitHub Pages chỉ phục vụ frontend. Giao diện không chứa GitHub token và không thực hiện việc tạo tải qua một backend bí mật.
