# Cloud Android – bản đầu tiên

Đây là giao diện prototype chạy được ngay trên trình duyệt iPad.

## Có gì?
- Đăng ký / đăng nhập giao diện hoàn chỉnh.
- Trang quản lý Android Cloud.
- Nút Bật / Tắt / Remote.
- Responsive cho iPad/iPhone.

## Lưu ý quan trọng
Bản hiện tại dùng localStorage để mô phỏng tài khoản, KHÔNG phải hệ thống xác thực production. Không dùng nó để lưu mật khẩu thật.

Để thành website thật:
1. Tạo Supabase project.
2. Dùng Supabase Auth cho đăng ký/đăng nhập.
3. Tạo backend API.
4. Backend gọi hệ thống Android/emulator trên server.
5. Nối nút Start/Stop/Remote với API.

Không nên đưa service key bí mật vào frontend.
